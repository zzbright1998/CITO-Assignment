from cProfile import label
from cmath import cos
from glob import glob
from hashlib import sha1
from multiprocessing.reduction import recv_handle
from scipy.fftpack import ss_diff
import torch
import tomosipo as ts
from ts_algorithms import fbp, sirt, tv_min2d, fdk, nag_ls
import pylab
import matplotlib.pyplot as plt
import fbp_c_V2
from torch import nn
import numpy as np
import trainning_data
import random
import astra
import cv2

width = 256



def prepare(angle):
    
    aa = int(width/4)
    bb = int(width/3)
    #---------------------------------------------------------------------------
    # Setup up volume and parallel projection geometry

    global vg, pg, A, vg1, pg1, A1, x, y1, rec_fbp1, less_angle

    less_angle = angle
    vg = ts.volume(shape=(1, width, width))
    pg = ts.parallel(angles=less_angle, shape=(1, width))
    A = ts.operator(vg, pg)

    vg1 = ts.volume(shape=(1, width, width))
    pg1 = ts.parallel(angles=512, shape=(1, width))
    A1 = ts.operator(vg1, pg1)


    # Create hollow cube phantom
    x = torch.zeros(A.domain_shape)
    x[:, aa:-aa, aa:-aa] = 1.0
    x[:, bb:-bb, bb:-bb] = 0.0

    # img1=cv2.imread("./phantom/9.jpg",cv2.IMREAD_GRAYSCALE)
    # img1=img1*(1/255)
    # x=torch.tensor(img1)
    # x=x[None,:,:]
    

    #---------------------------------------------------------------------------
    # high value image reconstruction
    y1 = A1(x) # Forward project
    rec_fbp1, _, _ = fbp_c_V2.fbp(A1, y1)
    pylab.gray()
    pylab.imshow(rec_fbp1[0],vmin=0,vmax=1)
    
    
    # pylab.show()
    




#---------------------------------------------------------------------------
def get_train_data(n_pixel, noise, x):
    y = A(x) # Forward project
    yy = y[0].numpy()
    y = astra.add_noise_to_sino((yy),noise)
    y = torch.tensor(y)
    y = y[None,:,:]
    # print(y.shape)

    rec_fbp, fbpfiltered, fbpNofiltered = fbp_c_V2.fbp(A, y)
    # pylab.gray()
    # pylab.imshow(rec_fbp[0],vmin=0,vmax=1)
    # pylab.show()

    #---------------------------------------------------------------------------

    n_pixel = n_pixel
    coor_list = list(range(width**2))
    random_coor_list = random.sample(coor_list, n_pixel)
    # print(random_coor_list)


    train_data=[]
    train_label=[]
    sum = 0
    for i in random_coor_list:
        x = i // width
        y = i % width
        
        data = trainning_data.get_project(fbpNofiltered, less_angle, width, x, y)
        train_data.append(data)
        train_label.append(rec_fbp1[0][x][y])
        
        sum += 1
        if sum%100 == 0:
            print('now getting the {}th pixel'.format(sum))


    train_data = np.reshape(train_data, (n_pixel, width))
    x_train = torch.tensor(train_data,requires_grad=True)
    x_train_zero = torch.zeros_like(x_train,requires_grad=True)
    # to 0-1
    m = torch.max(x_train)
    x_train = torch.mul(x_train, 1/m)
    # x_train = torch.where(x_train >= 0.02, x_train, x_train_zero)
    # x_train = torch.mul(x_train, 1/1500)
    # print(torch.max(x_train))
    # print(x_train.shape)


    y_train = torch.tensor(train_label,requires_grad=True)
    y_train = torch.reshape(y_train, (n_pixel,1))
    y_train_zero = torch.zeros_like(y_train,requires_grad=True)
    # y_train = torch.where(y_train >= 0.02, y_train, y_train_zero)
    # print(y_train)
    # print(y_train.shape)

    return x_train,y_train

#---------------------------------------------------------------------------

class Feedforward(torch.nn.Module):
        def __init__(self, input_size, hidden_size, output_size):
            super(Feedforward, self).__init__()
            self.input_size = input_size
            self.hidden_size  = hidden_size
            # self.hidden_size1  = hidden_size1
            self.output_size  = output_size
            self.fc1 = torch.nn.Linear(self.input_size, self.hidden_size)
            self.relu = torch.nn.ReLU()
            self.fc2 = torch.nn.Linear(self.hidden_size, self.output_size)
            self.sigmoid = torch.nn.Sigmoid()
            # self.fc3 = torch.nn.Linear(self.hidden_size1, self.output_size)
        def forward(self, x):
            hidden = self.fc1(x)
            relu = self.sigmoid(hidden)
            # hidden1 = self.fc2(relu)
            # relu1 = self.sigmoid(hidden1)
            output = self.fc2(relu)
            output = self.sigmoid(output)
            return output

def get_train():
    for i in range(50):
        t_data, t_lable = get_train_data(n_pixel=1000, noise=10000, x=x)

        if i == 0:
            x_train = t_data
            y_train = t_lable
        else:
            x_train = torch.cat((x_train, t_data), 0)
            y_train = torch.cat((y_train, t_lable), 0)
        
        print("slice {} is done".format(i))
        print(x_train.shape)
        print(y_train.shape)
    return x_train, y_train

def main(num, h_num):
    

    
    
    model = Feedforward(width, h_num, 1)
    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr = 0.005)


    print('x_train',x_train.shape,'y_train',y_train.shape)
    model.train()
    epoch = 20
    for epoch in range(epoch):
        
        for i in range(x_train.size(0)//32):
            optimizer.zero_grad()
            # Forward pass
            y_pred = model(x_train[i*32:(i+1)*32,:].float())
            # Compute Loss
            loss = criterion(y_pred, y_train[i*32:(i+1)*32])
            
            # Backward pass
            loss.backward(retain_graph=True)
            optimizer.step()
        print('Epoch {}: train loss: {}'.format(epoch, loss.item()))
    
    torch.save(model.state_dict(), 'model_param.pkl')
    #---------------------------------------------------------------
    # reconstruction

    y = A(x) # Forward project
    yy = y[0].numpy()
    y = astra.add_noise_to_sino((yy),10000)
    y = torch.tensor(y)
    y = y[None,:,:]
    rec_fbp, fbpfiltered, fbpNofiltered = fbp_c_V2.fbp(A, y)

    img = np.zeros((width,width))
    for i in range(width):
        for j in range(width):
            
            rec_proj = trainning_data.get_project(fbpNofiltered, less_angle, width, i, j)
            rec_proj = torch.tensor(rec_proj,requires_grad=True)
            # to 0-1
            rec_proj_zero = torch.zeros_like(rec_proj,requires_grad=True)
            m = torch.max(rec_proj)
            rec_proj = torch.mul(rec_proj, 1/m)
            rec_proj = torch.where(rec_proj >= 0.02, rec_proj, rec_proj_zero)

            recv_value = model(rec_proj.float())
            img[i][j] = recv_value
            # print(i,',',j,'',recv_value)
        print(i)

    # pylab.gray()
    # pylab.imshow(img,vmin=0,vmax=1)
    # pylab.show()

    rec_sirt = sirt(A, y, num_iterations=100)

    pylab.gray()
    pylab.subplot(141)
    pylab.axis('off')
    pylab.title('Phantom')
    pylab.imshow(x[0],vmin=0,vmax=1)
    pylab.subplot(142)
    pylab.axis('off')
    pylab.title('NNFBP-R')
    pylab.imshow(img,vmin=0,vmax=1)
    pylab.subplot(143)
    pylab.axis('off')
    pylab.title('FBP')
    pylab.imshow(rec_fbp[0],vmin=0,vmax=1)
    pylab.subplot(144)
    pylab.axis('off')
    pylab.title('SIRT')
    pylab.imshow(rec_sirt[0],vmin=0,vmax=1)
    pylab.tight_layout()
    pylab.savefig("1{}_angles_node_{}.png".format(num,h_num))
    # pylab.show()
    x1 = ((x[0] - img) ** 2).mean()
    x2 = ((x[0] - rec_fbp[0]) ** 2).mean()
    x3 = ((x[0] - rec_sirt[0]) ** 2).mean()
    
    f = open('angle{}_h{}.txt'.format(num,h_num),'w')
    f.write(str(x1)+'\n')
    f.write(str(x2)+'\n')
    f.write(str(x3)+'\n')
    f.close()



if __name__ == '__main__':
    # prepare(8)
    # main(8)

    # prepare(16)
    # main(16)

    # prepare(32)
    # x_train, y_train  = get_train()
    # main(32,4)
    # main(32,8)
    # main(32,16)
    # main(32,32)
    # main(32,64)


    # prepare(8)
    # x_train, y_train  = get_train()
    # main(8,64)

    # prepare(16)
    # x_train, y_train  = get_train()
    # main(16,64)

    prepare(32) #Setup up volume and parallel projection geometry
                #Import the reconstruction phantom
    
    x_train, y_train  = get_train()
                #Get training data
    
    main(32,64)
                #Using NNFBP-R for reconstruction. 32 angles, 64 hidden nodes


