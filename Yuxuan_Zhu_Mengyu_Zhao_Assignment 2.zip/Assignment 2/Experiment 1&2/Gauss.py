import cv2
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Wedge
from matplotlib.collections import PatchCollection
from PIL import Image
import random
import math


def randpos(x_start, x_end, y_start, y_end):
    return (np.random.randint(x_start, x_end),
            np.random.randint(y_start, y_end))


def gen_siemens_star(origin, radius, n):
    centres = np.linspace(0, 360, n + 1)[:-1]
    step = ((360.0 / n) / 4.0)
    patches = []
    for c in centres:
        patches.append(Wedge(origin, radius, c - step, c + step))
    return PatchCollection(patches, facecolors='k', edgecolors='none')


def get_siemens_star(dpi=2):
    fig, ax = plt.subplots(frameon=False, dpi=dpi)
    ax.add_collection(gen_siemens_star((0, 0), 1, 8))
    plt.axis('equal')
    plt.axis('off')
    plt.xticks([])
    plt.yticks([])
    canvas = fig.canvas
    buf, size = canvas.print_to_buffer()
    plt.clf()
    image = Image.frombuffer('RGBA', size, buf, 'raw', 'RGBA', 0, 1)
    image = image.convert('L')
    image = 255 - np.asarray(image)
    x, y = np.where(image == 255)
    xmin, xmax = x.min(), x.max()
    ymin, ymax = y.min(), y.max()
    image = image[xmin - 1: xmax + 1, ymin - 1: ymax + 1]
    return image


def get_rotate_rect():
    w = random.randint(2, pixel//5)
    h = random.randint(2, pixel//5)

    x = random.randint(w // 2, pixel - w // 2)
    y = random.randint(h // 2, pixel - h // 2)

    angel = random.randint(0, 360)
    angelPi = (angel / 180) * math.pi

    x1 = x + (w / 2) * math.cos(angelPi) - (h / 2) * math.sin(angelPi)
    y1 = y + (w / 2) * math.sin(angelPi) + (h / 2) * math.cos(angelPi)

    x2 = x + (w / 2) * math.cos(angelPi) + (h / 2) * math.sin(angelPi)
    y2 = y + (w / 2) * math.sin(angelPi) - (h / 2) * math.cos(angelPi)

    x3 = x - (w / 2) * math.cos(angelPi) + (h / 2) * math.sin(angelPi)
    y3 = y - (w / 2) * math.sin(angelPi) - (h / 2) * math.cos(angelPi)

    x4 = x - (w / 2) * math.cos(angelPi) - (h / 2) * math.sin(angelPi)
    y4 = y - (w / 2) * math.sin(angelPi) + (h / 2) * math.cos(angelPi)
    contours = np.array([[[x1, y1]], [[x2, y2]], [[x3, y3]], [[x4, y4]]])
    contours = contours.astype(np.int32)
    return contours


for num in range(10):
    # pixel = 512
    pixel = 256

    img_ = np.zeros([pixel, pixel], np.uint8)

    for i in range(2):
        x = np.random.randint(pixel//6, pixel - pixel//6)
        y = np.random.randint(pixel//6, pixel - pixel//6)
        radius = np.random.randint(25, 30)
        img_circle = cv2.circle(img_, (x, y), radius, pixel//2-1, -1)
        img_circle = cv2.GaussianBlur(img_circle, (61, 61), -1)
        img_ = cv2.add(img_, img_circle)

    for i in range(3):
        dsize = np.random.randint(2, 24)
        x = np.random.randint(0, pixel - 24 * 4)
        y = np.random.randint(0, pixel - 24 * 4)
        star = get_siemens_star(dpi=dsize)
        img_[x: x + star.shape[0], y: y + star.shape[1]] |= star

    for i in range(2):
        img_ = cv2.drawContours(img_, [get_rotate_rect()], -1, 255, -1)

    cv2.imwrite(f"{num}" + ".jpg", img_)
