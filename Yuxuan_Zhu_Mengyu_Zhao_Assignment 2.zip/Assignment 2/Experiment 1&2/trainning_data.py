import numpy as np
import math

def offset_pixel (coor_x, coor_y, width):
    if width%2 == 0: # width is even
        off = width/2
        coor_x = coor_x + 1 - off
        coor_y = coor_y + 1 - off
    else:
        off = (width-1)/2
        coor_x = coor_x - off
        coor_y = coor_y - off

    return coor_x, coor_y

def get_project_shift(angle_num, coor_x, coor_y, width):

    coor_x, coor_y = offset_pixel(coor_x,coor_y,width)
    detector_l, detector_r = offset_pixel(0,width-1,width)
 
    angle_list = []
    for i in range(angle_num):
        detec_list = []

        current_angle = (i*np.pi)/((angle_num-1)*2)
        pro_offset = coor_x*math.cos(current_angle)+coor_y*math.sin(current_angle)
        
        for j in range(int(detector_l), int(detector_r)+1):
            
            pro_offset_t = pro_offset - j
            # a list of offset, length = detector number
            detec_list.append(pro_offset_t)
        
        angle_list.append(detec_list)
    
    return angle_list

def get_project(project_data, angle_num, width, coor_x, coor_y):

    angle_list = get_project_shift(angle_num, coor_x, coor_y, width)
    angle_list = np.array(angle_list)
    angle_list = np.reshape(angle_list, (angle_num, width))

    off_l, doff_r = offset_pixel(0,width-1,width)
    project_data_shift = np.zeros(width)

    ang_num = angle_list.shape[0] 
    det_num = angle_list.shape[1] 

    for i in range(det_num): 
        sum_value = 0

        for j in range(ang_num): 
            off = angle_list[j][i]
            off = int(off - off_l) # + len/2
            #print(off)
            if off>=0 and off<width:
                proj_value = project_data[0][j][off]
                sum_value = sum_value + proj_value

        project_data_shift[i] = sum_value

    return project_data_shift