#! /bin/bash
python setup.py sdist --owner=root --group=root --formats=zip
