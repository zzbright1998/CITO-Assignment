from hashlib import sha1
import torch
import tomosipo as ts
from ts_algorithms import fbp, sirt, tv_min2d, fdk, nag_ls
import pylab
import matplotlib.pyplot as plt
import fbp_c
from torch import nn
import numpy as np

# Setup up volume and parallel projection geometry
vg = ts.volume(shape=(1, 256, 256))
pg = ts.parallel(angles=1024, shape=(1, 256))
A = ts.operator(vg, pg)
print(A.domain_shape)


# Create hollow cube phantom
x = torch.zeros(A.domain_shape)
x[:, 70:-70, 70:-70] = 1.0
x[:, 100:-100, 100:-100] = 0.0
print(x.shape)
# pylab.gray()
# plt.imshow(x.permute(1, 2, 0))
# pylab.imshow(x[0])
# pylab.show()


# Forward project
y = A(x)
rec_fbp, fbpfiltered, _ = fbp_c.fbp(A, y)
print('1024*256 label',fbpfiltered.shape)

start_a = 8
end_a = 256
step_a = 8
for angle in range(start_a, end_a, step_a):

    # print(angle)
    vg_t = ts.volume(shape=(1, 256, 256))
    pg_t = ts.parallel(angles=angle, shape=(1, 256))
    A_t = ts.operator(vg_t, pg_t)

    #Forward project to get less angle data reconstrction
    y_t = A_t(x)
    rec_fbp_t, _, _ = fbp_c.fbp(A_t, y_t)
    # print(rec_fbp.shape)

    #Sample the projection for training
    y_s = A(rec_fbp_t)
    r, fbpfiltered_s, fbpNofiltered_s = fbp_c.fbp(A, y_s)
    print('fbpfiltered_s',fbpfiltered_s.shape, 'angle', angle)

   

    pylab.gray()
    pylab.imshow(r[0],vmin=0,vmax=1)
    # pylab.show()


    #Prepare for the training data
    if angle == start_a:
        x_train = fbpfiltered_s
        y_train = fbpfiltered
    else:
        x_train = torch.cat([x_train, fbpfiltered_s], dim=1)
        y_train = torch.cat([y_train, fbpfiltered], dim=1)
x_train = x_train[0]
y_train = y_train[0]
print(x_train)
print(y_train)
# print('dim_xtrain',x_train.shape,'dim_ytrain',y_train.shape)


# reconstructions made with different algorithms
# rec_fbp = fbp_c.fbp(A, y)
# rec_sirt = sirt(A, y, num_iterations=100)
# rec_tv_min = tv_min2d(A, y, 0.0001, num_iterations=100)
# rec_nag_ls = nag_ls(A, y, num_iterations=100)
# pylab.gray()
# pylab.imshow(rec_fbp[0],vmin=0,vmax=1)
# pylab.show()

# class Perceptron(torch.nn.Module):
#     def __init__(self):
#         super(Perceptron, self).__init__()
#         self.fc = nn.Linear(1,1)
#         self.relu = torch.nn.ReLU() # instead of Heaviside step fn
#     def forward(self, x):
#         output = self.fc(x)
#         output = self.relu(x) # instead of Heaviside step fn
#         return output

class Feedforward(torch.nn.Module):
        def __init__(self, input_size, hidden_size, hidden_size1, output_size):
            super(Feedforward, self).__init__()
            self.input_size = input_size
            self.hidden_size  = hidden_size
            self.hidden_size1  = hidden_size1
            self.output_size  = output_size
            self.fc1 = torch.nn.Linear(self.input_size, self.hidden_size)
            self.relu = torch.nn.ReLU()
            self.fc2 = torch.nn.Linear(self.hidden_size, self.hidden_size1)
            self.sigmoid = torch.nn.Sigmoid()
            self.fc3 = torch.nn.Linear(self.hidden_size1, self.output_size)
        def forward(self, x):
            hidden = self.fc1(x)
            relu = self.relu(hidden)
            hidden1 = self.fc2(relu)
            relu1 = self.relu(hidden1)
            output = self.fc3(relu1)
            output = self.sigmoid(output)
            return output



model = Feedforward(256, 4, 4, 256)
criterion = torch.nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr = 0.001)

# model.eval()
# y_pred = model(x_test)
# before_train = criterion(y_pred.squeeze(), y_test)
# print('Test loss before training' , before_train.item())

print('x_train',x_train.shape,'y_train',y_train.shape)
model.train()
epoch = 50
for epoch in range(epoch):
    
    for i in range(x_train.size(0)//32):
        optimizer.zero_grad()
        # Forward pass
        y_pred = model(x_train[i*32:(i+1)*32,:])
        # Compute Loss
        loss = criterion(y_pred, y_train[i*32:(i+1)*32,:])
        
        # Backward pass
        loss.backward()
        optimizer.step()
    print('Epoch {}: train loss: {}'.format(epoch, loss.item()))
    
 
vg_t = ts.volume(shape=(1, 256, 256))
pg_t = ts.parallel(angles=16, shape=(1, 256))
A_t = ts.operator(vg_t, pg_t)

#Forward project to get less angle data reconstrction
y_t = A_t(x)
rec_fbp_t, fbpfiltered_s, fbpNofiltered_s = fbp_c.fbp(A_t, y_t)
# print(rec_fbp.shape)
filter_niubi = model(fbpfiltered_s[0])
filter_niubi = filter_niubi[None,:,:]
rec = A_t.T(filter_niubi)
vg, pg = A_t.astra_compat_vg, A_t.astra_compat_pg

pixel_height = (pg.det_size[0] / pg.det_shape[0])
voxel_volume = np.prod(np.array(vg.size / np.array(vg.shape)))
scaling = (np.pi / pg.num_angles) * pixel_height / voxel_volume

rec *= scaling


pylab.gray()
pylab.imshow(rec[0],vmin=0,vmax=1)
pylab.show()