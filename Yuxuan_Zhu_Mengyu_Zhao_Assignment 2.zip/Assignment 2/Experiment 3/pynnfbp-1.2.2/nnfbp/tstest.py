import torch
import tomosipo as ts
from ts_algorithms import fbp, sirt, tv_min2d, fdk, nag_ls
import pylab
import matplotlib.pyplot as plt
import fbp_c

# Setup up volume and parallel projection geometry
vg = ts.volume(shape=(1, 256, 256))
pg = ts.parallel(angles=4096, shape=(1, 256))
A = ts.operator(vg, pg)
print(A.domain_shape)


# Create hollow cube phantom
x = torch.zeros(A.domain_shape)
x[:, 70:-70, 70:-70] = 1.0
x[:, 100:-100, 100:-100] = 0.0
print(x.shape)
pylab.gray()
plt.imshow(x.permute(1, 2, 0))
pylab.imshow(x[0])
pylab.show()
# Forward project
y = A(x)

# reconstructions made with different algorithms
rec_fbp = fbp_c.fbp(A, y)
rec_sirt = sirt(A, y, num_iterations=100)
rec_tv_min = tv_min2d(A, y, 0.0001, num_iterations=100)
rec_nag_ls = nag_ls(A, y, num_iterations=100)
pylab.gray()
pylab.imshow(rec_fbp[0],vmin=0,vmax=1)
pylab.show()
