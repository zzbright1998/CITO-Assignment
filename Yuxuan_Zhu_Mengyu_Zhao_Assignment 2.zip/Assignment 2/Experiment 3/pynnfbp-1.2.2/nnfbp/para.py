import imp
import fbp_c_V2
import torch
import tomosipo as ts
import pylab
import matplotlib.pyplot as plt
import fbp_c_V2
from torch import nn
import numpy as np
import astra
import cv2

import os
import torch

width = 256
aa = int(width/4)
bb = int(width/3)

vg = ts.volume(shape=(1, width, width))
pg = ts.parallel(angles=64, shape=(1, width))
A = ts.operator(vg, pg)
vg1 = ts.volume(shape=(1, width, width))
pg1 = ts.parallel(angles=512, shape=(1, width))
A1 = ts.operator(vg1, pg1)

img1=cv2.imread("./4.jpg",cv2.IMREAD_GRAYSCALE)
img1=img1*(1/255)
x=torch.tensor(img1)
x=x[None,:,:]

loaded_paras = torch.load('model_param.pkl')

for param_tensor in loaded_paras:
    print(param_tensor, "\t", loaded_paras[param_tensor].size())

ww = loaded_paras['fc1.weight']
bb = loaded_paras['fc1.bias']
w2 = loaded_paras['fc2.weight']
b2 = loaded_paras['fc2.bias']

print(ww.size())
sigmoid = torch.nn.Sigmoid()

for i in range(ww.size(0)):
    print(ww[i].size())
    
    
    y = A(x) # Forward project
    yy = y[0].numpy()
    y = astra.add_noise_to_sino((yy),10000)
    y = torch.tensor(y)
    y = y[None,:,:]
    rec_fbp, fbpfiltered, fbpNofiltered = fbp_c_V2.fbp(A, y, filter=ww[i])
    rec_fbp = torch.add(rec_fbp, bb[i])
    rec_fbp = sigmoid(rec_fbp)

    rec_fbp = rec_fbp*w2[0][i]

    if i == 0:
        img = rec_fbp
    else:
        img = img + rec_fbp
img = torch.add(img, b2[0])
img = sigmoid(img)

print(img)
pylab.gray()
pylab.imshow(img[0],vmin=0,vmax=1)
pylab.show()
